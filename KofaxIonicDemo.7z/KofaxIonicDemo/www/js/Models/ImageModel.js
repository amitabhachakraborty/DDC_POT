angular.module('starter.imageObject', [])

.factory('ImageModel', function() {
         // This Model class we are treating as an Object Class to set and get properties.
         // This class will act as a singleton class
         
         var imageObject = {
         imageid: 0,
         imageBase64String: '',
         processedImageBase64: '',
         imageObject: '',
         };
         
         return {
         get: function() {
         return imageObject;
         }
         };
 });
