
//starter.CameraController this is module name for this controller. we have to inject this in to app.js module.
angular.module('starter.CameraController', [])


//CameraCtrl this is a unique key that is representing CameraController. It is used at the time of Routing in app.js.
.controller('CameraCtrl', function($scope, $timeout ,ImageModel , $state , $window) {

            // With the new view caching in Ionic, Controllers are only called
            // when they are recreated or on app start, instead of every page change.
            // To listen for when this page is active (for example, to refresh data),
            // listen for the $ionicView.enter event:

            //$scope : is the application object (the owner of application variables and functions).
            //$timeout : The $timeout service can be used to call another JavaScript function after a given time delay. The $timeout service only schedules a single call to the function.

            // imageCaptureControl class object
            var imageCaptureControl = null;
            // imageCaptureControl properties object
            var imageCaptureViewProperties = null;

            // DocumentCatureExperience class object
            var documentCatureExperience = null;
            // DocumentCatureExperience properties object
            var documentCaptureViewProperties = null;

            // The retrieved ID can be  used to bind any capture experiences with the ImageCapture Control.
            var imageCaptureControlID = null;

            // storing captured image
            var imageObject = null;
            // This object will have all captured images
            var ImageArray = null;
            //  camera view frame
            var layoutProperties = null;


            // Form data for the login modal

            // Called when page loading complete
            $scope.$on('$ionicView.loaded', function (viewInfo, state) {
                       console.log('CTRL - $ionicView.loaded', viewInfo, state);

              $scope.initializeOptions();


                       });

            // Called  before enter into this page.
            $scope.$on('$ionicView.beforeEnter', function (viewInfo, state) {
                       console.log('CTRL - $ionicView.beforeEnter', viewInfo, state);

                       });

            //Called when view is about to leave
            $scope.$on('$ionicView.beforeLeave', function (viewInfo, state) {

                       $scope.removeCamera();
                       imageCaptureControl = null;

                       });

            //Called when view is unloaded
            $scope.$on('$ionicView.unloaded', function (viewInfo, state) {


                       });


            //Called to  remove listeners added to camera and cleans up memory by calling removeCameraView
            $scope.removeCamera = function()
            {
                $scope.removeImageCaptureListeners();
                imageCaptureControl.removeCameraView(function(result) {
                       console.log("removeCameraView success");
                }, function(error) {
                       alert("removeCameraView error !" + error);
                });
            }


  //This event fires when the camera is initialized or reinitialized
  //On successful initialization of camera associate the respective capture control with specified options i.e.DocumentCaptureExperience in this case
  var cameraInitializeHandler = function(result) {

    console.log("Camera initialization raised success callback " + JSON.stringify(result));
    //To get the unique Id for imageCaptureControl.This id is needed to differentiate different capture controls if present

    imageCaptureControl.getId(function(getIdSuccess) {
      imageCaptureControlID = getIdSuccess;

        //Method to associate the created ImageCapture Control with the DocumentCaptureExperience class
        documentCatureExperience.bindCaptureControl(function(bindCaptureControlSuccess) {

          documentCatureExperience.setOptions(function(success) {

            console.log('DocumentCaptureExperience.setOptions' + success);
            $scope.addImageCaptureListeners();
            }, function(error) {
            alert('DocumentCaptureExperience.setOptions' + error);
          }, documentCaptureViewProperties);
        }, function(error) {
          alert('DocumentCaptureExperience.bindCaptureControl' + error);

        }, imageCaptureControlID);

    }, function(error) {
      alert('imageCaptureControl.getID' + error);
    });
  };

            //To add KofaxSDK camera to the view
            $scope.showImageCaptureView = function() {

            // setting camera view frame.
            renderCameraLayout();

            //Calling this method would add a listener which would be called upon successful initialization.
            imageCaptureControl.addCameraInitializationListener(function(result) {
                   /*
                    *Add cameraView with parameter "layoutProperties" obtained from renderCameraLayout()
                    */

                    imageCaptureControl.addCameraView(function(result) {
                        console.log("Camera added success");
                      }, function(error) {
                        alert("imageCaptureControl.addCameraView error !" + error);
                    }, layoutProperties);
                }, function(error) {
                        alert("imageCaptureControl.addCameraInitializer error !" + error);
              }, cameraInitializeHandler);

            };


            //Force take picture button action in capture view
            $scope.forceTakePicture = function()
            {
                imageCaptureControl.forceTakePicture(function(result) {
                    console.log("force takePicture success");

                }, function(error) {
                    alert("force takePicture error!" + error)
              });
            }


            //Calling this method would add a listener which would be called when image is captured.

            $scope.addImageCaptureListeners = function()
            {


            //  A JSON object containg the properties of the captured image object. Check the 'Image'  object for its properties.
            var imageCaptureCallback = function(imgObject) {

            // Get base64 data from image array by passing the
            // image id as parameter and displaying the image
            imgObject.base64Image(function(base64Success) {
                                  console.log("Base64 image success callback");
                                  // Remove the previous taken image from the image array
                                  if (imageObject) {
                                  imageObject.deleteImage(function(result) {
                                                          console.log("Delete image success callback " + JSON.stringify(deleteImageSuccess));
                                                          }, function(deleteImageError) {
                                                          alert("Delete image error callback " + JSON.stringify(deleteImageError));
                                                          console.log("Delete image error callback " + JSON.stringify(deleteImageError));
                                                          });
                                  }

                                  //Get the imageObj obtained from callBack and assign it to reference variable
                                  imageObject = imgObject;

                                  // setting imageObject and imageBase64String for ImageModel Class . that will be accessible through out the project
                                  // We are using imageBase64String for showing preview
                                  var image = ImageModel.get();
                                  image.imageObject = imgObject;
                                  image.imageBase64String = base64Success;

                                  $state.go('Preview', {}, {reload: true});

                                  }, function(base64Error) {

                                  alert("Base64 image error callback " + JSON.stringify(base64Error));
                                  console.log("Base64 image error callback " + JSON.stringify(base64Error));
                                  });
            }
            /*
             //Calling this method would add a listener which would be called when image is captured succesfully.
             */
            documentCatureExperience.addImageCapturedListener(function (success) {
              documentCatureExperience.takePicture(function(result) {
                console.log("takePicture success");
              }, function(err) {
                alert("takePicture error!" + err);
              });
            }, function (error) {
              alert("addImageCapturedListener error callback " + error);
            }, imageCaptureCallback);
    }

            // initialising camera options
            $scope.initializeOptions = function(){

            imageCaptureControl = kfxCordova.kfxUicontrols.createImageCaptureControl();
            ImageArray = kfxCordova.kfxEngine.createImageArray();
            documentCatureExperience = kfxCordova.kfxUicontrols.createDocumentCaptureExperience();
            imageCaptureViewProperties = imageCaptureControl.getImageCaptureViewOptions();
            documentCaptureViewProperties = documentCatureExperience.getDocumentCaptureOptions();
            $scope.showImageCaptureView();

            }




            /*On successful capture of image,preview of captured image is shown and camera is cleaned up from the memory .So any listeners associated with the camera are removed viz.CameraInitializationListener,ImageCapturedListener,CameraInitializationFailedListener
             *So in this function we first remove cameraInitializationListener.On receiving successcallBack ImageCapturedListener is removed
             */

            $scope.removeImageCaptureListeners = function() {

            var successCallback = function(removeImageCapturedSuccess) {

            console.log("Remove image captured listener success callback " + JSON.stringify(removeImageCapturedSuccess));

            };

            var errorCallback = function(removeImageCapturedError) {

            alert("Remove image captured listener error callback " + JSON.stringify(removeImageCapturedError));

            console.log("Remove image captured listener error callback " + JSON.stringify(removeImageCapturedError));

            };

            //Remove image captured listener
            documentCatureExperience.removeImageCapturedListener(successCallback, errorCallback);

            imageCaptureControl.removeCameraInitializationListener(function(removeCameraInitializationSuccess) {

                console.log("Remove camera initialization listener success callback " + JSON.stringify(removeCameraInitializationSuccess));

                }, function(removeCameraInitializationError) {

                  alert("Remove camera initialization listener error callback " + JSON.stringify(removeCameraInitializationError));

                   console.log("Remove camera initialization listener error callback " + JSON.stringify(removeCameraInitializationError));

           });

        }


            //*******************************************************
            //This method renders the camera layout.
            function renderCameraLayout(){

            //Get the layout properties of cordova.
            layoutProperties = kfxCordova.getLayoutProperties();

            //Get the layout properties of cordova.

            // calculated camera height and width
            var headerHeight = 64;
            var footerHeight = 44;
            var widthh = $window.innerWidth;
            var height = $window.innerHeight-headerHeight-footerHeight;

            //Initialise x position to 0
            layoutProperties.x = 0;
            //Get the height of the header which is 'captureheader'
            layoutProperties.y = headerHeight;
            //Width of the camera is the width of the window
            layoutProperties.width = widthh;
            //Calculate the total height left for the camera
            layoutProperties.height = height;
            }



    })

