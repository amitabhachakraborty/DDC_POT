angular.module('starter.HomeController', [])

.controller('HomeCtrl', function($scope , $ionicPlatform, $timeout) {

            // With the new view caching in Ionic, Controllers are only called
            // when they are recreated or on app start, instead of every page change.
            // To listen for when this page is active (for example, to refresh data),
            // listen for the $ionicView.enter event:
            var License = null;

            $ionicPlatform.ready(function() {

              $scope.setLicence();

            });

            $scope.$on('$ionicView.enter', function(e) {

            });

            $scope.$on('$ionicView.loaded', function (viewInfo, state) {

              console.log('CTRL - $ionicView.loaded', viewInfo, state);

            });


            /*
             *kfxUtilities contains methods related to license
             *Create an instance of license and set the license obtained from Kofax
             *If license is set successfully add Camera.Adding camera if license is not set successfully will show a blank screen
             */

            $scope.setLicence = function()
            {
               //License has to be set to launch KofaxSDK Camera.

            //Create an instance of License

                License = kfxCordova.kfxUtilities.createLicense();

            //Set Mobile SDK License.If license is set successfully call addCamera to launch Kofax SDK camera
            //you just need to replace 'Add Licence Here' key with valid licence String

                License.setMobileSDKLicense(function(setLicenseSuccess) {
                    console.log("Set license success callback " + JSON.stringify(setLicenseSuccess));
                    
                }, function(setLicenseError) {
                    alert("Set license error callback " + JSON.stringify(setLicenseError));
                    console.log("Set license error callback " + JSON.stringify(setLicenseError));
                }, 'Add License here');
            }

            //To fetch the information related to MobileSDK.
            $scope.getMobileSDKLicence = function()
            {
            console.log("Cordova Version is " + JSON.stringify(kfxCordova.getCordovaVersion()));
            }
})

