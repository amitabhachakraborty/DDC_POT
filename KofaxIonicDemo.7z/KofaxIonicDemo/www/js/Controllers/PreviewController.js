angular.module('starter.PreviewController', [])
.controller('PreviewCtrl', function($scope, $timeout , ImageModel, $state , $ionicActionSheet , $ionicPopup ,$ionicLoading) {

            // With the new view caching in Ionic, Controllers are only called
            // when they are recreated or on app start, instead of every page change.
            // To listen for when this page is active (for example, to refresh data),
            // listen for the $ionicView.enter event:
            //$scope.$on('$ionicView.enter', function(e) {
            //});


            // ImageProcessor class object
            var ImageProcessor = null;
            // storing processed image
            var processedImageObject = null;
            // getting the Captured Image object , ImageModel is like singleton Class
            var image = ImageModel.get();
            // assining base64String to Preview.html imageData key
            $scope.imageData = image.imageBase64String;
            var imageObject = image.imageObject;
            // by default use Basic setting Profile for processing
            var isBasicProfileActive = true;



            // called when this page will be unloaded
            $scope.$on('$ionicView.unload', function (viewInfo, state) {
                       console.log('CTRL - $ionicView.beforeEnter', viewInfo, state);

                       // removing All instances memory
                       // removing ImageProcess listeners
                       $scope.removeImageProcessorListeners();
                       // making all objects null for removing their memory
                        ImageProcessor = null;
                        processedImageObject = null;
                        imageObject = null;
                    });


            // called this method when page loaded
            $scope.$on('$ionicView.loaded', function (viewInfo, state) {

                       });

            // called this method befor page loaded
            $scope.$on('$ionicView.beforeEnter', function (viewInfo, state) {
                        console.log('CTRL - $ionicView.beforeEnter', viewInfo, state);
                       // initialising all required objects
                        ImageProcessor = kfxCordova.kfxEngine.createImageProcessor();

                       // adding imageProcessor listeners
                        $scope.addImageProcessorListeners();


                });


            // this method will call on process Button clicked.
            $scope.processImage = function()
            {
              $scope.setProcessorOptions();

            }


            $scope.setProcessorOptions = function() {

            // assigning imageProcessorOptions to local object. This is just an app logic to set ImagePerfectionProfile or BasicSettingsProfile properties
            var imageProcessingSettings = ImageProcessor.getImageProcessingOptions();
              imageProcessingSettings.BasicSettingsProfile.outputBitDepth = "GRAYSCALE";
              imageProcessingSettings.BasicSettingsProfile.outputDPI = 240;
              imageProcessingSettings.ImagePerfectionProfile = null;
                ImageProcessor.setImageProcessorOptions(ipOptionsSetCB,
                        function(result) {
                            // errorCB :    error message would contain the appropriate error description.Possible error objects are Wrong Parameters, KmcRuntimeException & Exception.
                            alert("Error! setImageProcessorOptions" + JSON.stringify(result));
                }, imageProcessingSettings);
            }


            var ipOptionsSetCB = function(message) {
                ImageProcessor.processImage(function(result) {
                            console.log("Success! processImage" + result);
                }, function(result) {
                            alert("Error! processImage " + JSON.stringify(result));
                }, imageObject.imgID);
            };


            /*
             * Adds Image processing Listeners
             *
             */

            $scope.addImageProcessorListeners = function() {

                    ImageProcessor.addImageOutEventListener(function(imageOutSuccess) {

                    console.log("Image out listener registered success callback " + JSON.stringify(imageOutSuccess));

                    }, function(imageOutError) {

                    alert("Image out listener error callback " + JSON.stringify(imageOutError));
                    console.log("Image out listener error callback " + JSON.stringify(imageOutError));

                    // hiding ProcessingLoader
                    $ionicLoading.hide();

                }, imageOutHandler);
            }
        /*
         * Removes Image processing Listeners
         *
         */
            $scope.removeImageProcessorListeners = function() {


                ImageProcessor.removeImageOutEventListener(function(imageOutSuccess) {

                   console.log("Remove image out listener success callback " + JSON.stringify(imageOutSuccess));

                   }, function(imageOutError) {

                   alert("Remove image out listener error callback " + JSON.stringify(imageOutError));

                   console.log("Remove image out listener error callback " + JSON.stringify(imageOutError));

                   });

            }

            /*
             * will be invoked, once image processing gets completed
             *
             * @gets processed image imageId
             *
             //  imageOutHandler : will have the processed image properties returned in the form of a JSON object
             */
            var imageOutHandler = function(message) {

            //assigning processed output image to our local processedImageObject variable
                processedImageObject = message;

            // hiding ProcessingLoader
                $ionicLoading.hide();

            /// To generate a base64 string (of an ImageObject)
            // Method to convert an image to the form of base64string from a Image.
                processedImageObject.base64Image(function(base64Success) {

                    console.log("Base64 image success callback");

                    // Remove the previous taken image from the image array
                    if (processedImageObject) {
                           /// To delete  the imageObject
                           // Method to delete the imageObject (Image).

                        processedImageObject.deleteImage(function(result) {

                        console.log("Delete image success callback " + JSON.stringify(result));

                    }, function(deleteImageError) {

                        alert("Delete image error callback " + JSON.stringify(deleteImageError));

                        console.log("Delete image error callback " + JSON.stringify(deleteImageError));
                    });
                    }


                   image.processedImageBase64 = base64Success;

                   // navigating to Process preview Screen
                   $scope.showProcessedImage();


                   }, function(base64Error) {

                   alert("Base64 image error callback " + JSON.stringify(base64Error));

                   console.log("Base64 image error callback " + JSON.stringify(base64Error));

                   });
            console.log("Success ImageOutEventListener message" + message);
         }



            // After processing image navigating to ProcessController
            $scope.showProcessedImage = function(){
            $state.go('Process', {}, {reload: true});
            }


            $scope.showAlert = function(title,message)
            {
                $ionicPopup.alert({
                              title: title,
                              template: message
                              });
            }


            $scope.retakeClicked = function()
            {
                $state.go('Camera', {}, {reload: false});
            }




})

