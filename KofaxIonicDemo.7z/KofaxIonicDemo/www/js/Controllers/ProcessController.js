angular.module('starter.ProcessController', [])
.controller('ProcessCtrl', function($scope, $timeout ,$ionicHistory , ImageModel) {
            
            // With the new view caching in Ionic, Controllers are only called
            // when they are recreated or on app start, instead of every page change.
            // To listen for when this page is active (for example, to refresh data),
            // listen for the $ionicView.enter event:
            
            // Called when page start loading
            $scope.$on('$ionicView.enter', function(e) {
            });
            
            // This Controller will display Image Preview for processed image
            var image = ImageModel.get();
            //assigining processedImageBase64 image to html imageData key (Data binding for imageData)
            $scope.imageData = image.processedImageBase64;
            
            // caled when unload the page
            $scope.$on('$ionicView.unloaded', function (viewInfo, state) {
                       
            });
            
})

