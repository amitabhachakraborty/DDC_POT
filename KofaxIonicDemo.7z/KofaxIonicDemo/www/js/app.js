// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
angular.module('starter', ['ionic' , 'starter.HomeController','starter.CameraController','starter.imageObject' , 'starter.PreviewController', 'starter.ProcessController'])
.config(function($stateProvider, $urlRouterProvider) {


        $stateProvider
        .state('Home', {
               cache: true,
               url: '/1',
               templateUrl: "views/home.html",
               controller : "HomeCtrl"
               })
        .state('Camera', {
               cache: false,
               url: '/1',
               templateUrl: "views/camera.html",
               controller : "CameraCtrl"
               })
        .state('Preview', {
               cache: false,
               url: '/1',
               templateUrl: "views/preview.html",
               controller : "PreviewCtrl"
               })
        .state('Process', {
               cache: false,
               url: '/1',
               templateUrl: "views/process.html",
               controller : "ProcessCtrl"
               })

        $urlRouterProvider.otherwise("/1");
        })
