##################################################################################
			Instructions to build and run Kofax Ionic Demo
##################################################################################

1. ionic start KofaxIonicDemo blank
 Will created new Ionic project, assuming the ionic CLI setup inplace.

2. Copy www contents
 Goto KofaxIonicDemo Folder. Copy & Replace existing www contents with corresponding files given.

3. cd KofaxIonicDemo

4. ionic platform add android
 If there is no ionic.config.json under project root folder, add manually. 

5. ionic plugin add << kofaxPluginPath >>

<< kofaxPluginPath >> needs to be replace with local system path. 
For ex ...\Hybrid\PhoneGap\Plugins\com.kofax.mobile.plugins.sdk

6.  Add Kofax Licence String in HomeController.js

7. Copy Kofax libraries from Android\MobileSDK_libs\aar to KfxIonicDemo\platforms\android\libs.

8. Open build.gradle file under ...\KfxIonicDemo\platforms\android

9. Add the following lines in dependencies { .... }
		repositories {
			flatDir {
			dirs 'libs'
			}
		}
		compile (name: 'sdk-release', ext: 'aar')

10. Add the following lines in Android { .... }

		packagingOptions {
			exclude 'META-INF/LICENSE.txt'
			exclude 'META-INF/NOTICE.txt'
			exclude 'META-INF/DEPENDENCIES'
			exclude 'META-INF/LICENSE'
			exclude 'META-INF/NOTICE'
		}

11. ionic build android

12. ionic run android
